package com.ronitdev.LocalHotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalHotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalHotelApplication.class, args);
	}

}
