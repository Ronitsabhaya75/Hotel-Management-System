package com.ronitdev.LocalHotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
